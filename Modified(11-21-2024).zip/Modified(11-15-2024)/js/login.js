let user = document.getElementById("email");
let pass = document.getElementById("pass");
let login = document.getElementById("login");
let userIsLogin = sessionStorage.getItem("user");

// Regular user and admin data
let data = [
    {
        "username": "Kent",
        "password": "123",
        "role": "user"
    },
    {
        "username": "Kentoy",
        "password": "123",
        "role": "user"
    },
    {
        "username": "Ruisu",
        "password": "123",
        "role": "admin"
    },
    {
        "username": "Admin",
        "password": "123",
        "role": "admin" // Admin role
    }
];

// Redirect if already logged in
if (userIsLogin) {
    alert("Please Logout First!");
    window.location = "../html/salesRecord.html"; // Redirect to salesRecord or admin.html based on role
}

login.addEventListener("click", function () {
    const loggedInUser = checkLogin(user.value, pass.value);

    if (loggedInUser) {
        // Set session storage for the logged-in user
        sessionStorage.setItem("user", loggedInUser.username);
        sessionStorage.setItem("role", loggedInUser.role); // Store role in session

        // Redirect based on role
        if (loggedInUser.role === "admin") {
            window.location = "../html/admin.html"; // Redirect to admin.html for admin
        } else {
            window.location = "../html/salesRecord.html"; // Redirect to salesRecord.html for regular users
        }
    } else {
        alert("Invalid Credentials!!");
    }
});

// Function to check login credentials
function checkLogin(username, password) {
    return data.find(user => user.username === username && user.password === password);
}

// Optional: Function to store username locally
function storeUsername() {
    var userInput = document.getElementById("user").value;
    localStorage.setItem("username", userInput);
    return true;
}